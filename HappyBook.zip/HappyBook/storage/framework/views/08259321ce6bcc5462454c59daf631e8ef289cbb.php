

<?php $__env->startSection('title', 'HappyBook - Contact Us'); ?>

<style>
    .section-title{
        font-size: 20px;
    }
</style>

<?php $__env->startSection('content'); ?>
    <div style = "font-size:30px">Contacts</div><br>
    <div class="section-title">
        Store Address:
    </div>
    <p>Jalan Pembangunan Baru Raya,<br>
    Kompleks Pertokoan Emerald Blok III/12<br>
    Bintaro, Tangerang Selatan<br>
    Indonesia</p><br>
    <div class="section-title">
        Open Daily:
    </div>
    <p>08:00 - 20:00</p><br>
    <div class="section-title">
        Contact-Info:
    </div>
    <p>Phone: 021-08899776655<br>
    Email: happybookstore@happy.com</p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\LaravelProjects\HappyBook\resources\views/contact.blade.php ENDPATH**/ ?>