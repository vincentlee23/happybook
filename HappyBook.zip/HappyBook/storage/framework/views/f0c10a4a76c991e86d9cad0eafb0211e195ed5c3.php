<link rel="stylesheet" href="<?php echo e(asset('front/css/content.css')); ?>">

<table class="table table-hover" id="display-books">
    <thead>
    <tr>
        <th scope="col" style="width: 60%">Title</th>
        <th scope="col">Author</th>
    </tr>
    </thead>
    <tbody>
    <tr>
        <td>Otto</td>
        <td>@mdo</td>
    </tr>
    <tr>
        <td>Thornton</td>
        <td>@fat</td>
    </tr>
    <tr>
        <td>Larry the Bird</td>
        <td>@twitter</td>
    </tr>
    </tbody>
</table><?php /**PATH C:\xampp\htdocs\LaravelProjects\HappyBook\resources\views/layouts/content.blade.php ENDPATH**/ ?>